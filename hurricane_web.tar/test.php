<?php

  echo gethostbyaddr($_SERVER['REMOTE_ADDR']), $_SERVER['REMOTE_ADDR'];
  echo date("Y-m-d G:i:s");
?>
