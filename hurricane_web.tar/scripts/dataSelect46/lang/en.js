var $lang={
errAlertMsg: "Invalid date or the date out of range,redo or not?",
aWeekStr: ["wk", "S", "M", "T", "W", "Th", "F", "S"],
aLongWeekStr:["wk","Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"],
aMonStr: ["Jan.","Feb.","March","April","May","June","July","August","Sept.","Oct.","Nov.","Dec."],
aLongMonStr: ["January","February","March","April","May","June","July","August","September","October","November","December"],
clearStr: "Clear",
todayStr: "Today",
okStr: "OK",
updateStr: "OK",
timeStr: "Time",
quickStr: "Quick Selection",
err_1: 'MinDate Cannot be bigger than MaxDate!'
}
